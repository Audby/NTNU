Oppgave 3:

Koden har det som kalles "race condition". Når rutinene uten skikkelig synkronisering inkrementerer og dekrementerer samtidig, kan de, uten videre steg, påvirke hverandre, hvilket kan gjøre at resultatet ikke alltid nødvendigvis blir null.

